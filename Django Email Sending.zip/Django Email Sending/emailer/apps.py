from django.apps import AppConfig


class EmailerConfig(AppConfig):
    name = 'emailer'
